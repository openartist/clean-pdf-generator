wp.blocks.registerBlockType('clean-pdf/download-pdf', {
    title: 'Download PDF',
    icon: 'download',
    category: 'widgets',

    edit: function(props) {
        return wp.element.createElement(
            wp.components.Button,
            {
                onClick: () => {
                    const xhr = new XMLHttpRequest();
                    xhr.open('POST', '/wp-admin/admin-ajax.php', true);
                    xhr.responseType = 'blob'; // Expect a PDF file (blob) in response

                    // Handle the response from the server
                    xhr.onload = function () {
                        if (this.status === 200) { // Check if the request was successful
                            const url = window.URL.createObjectURL(this.response);
                            const a = document.createElement('a');
                            a.style.display = 'none';
                            a.href = url;
                            a.download = 'page-content.pdf'; // Filename for the downloaded PDF
                            document.body.appendChild(a); // Append link to the document
                            a.click(); // Programmatically click the link to trigger the download
                            window.URL.revokeObjectURL(url); // Clean up by revoking the object URL
                            document.body.removeChild(a); // Remove the link from the document
                        } else {
                            alert('Failed to generate PDF.');
                        }
                    };

                    // Prepare the AJAX request
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    // Send the request with the action and the page's HTML content
                    xhr.send('action=generate_pdf&content=' + encodeURIComponent(document.documentElement.outerHTML));
                },
                isPrimary: true,
            },
            'Download PDF' // Button text
        );
    },

    save: function() {
        // This button markup will be saved with the post content and rendered on the front-end.
        return wp.element.createElement(
            'button',
            {
                className: 'pdf-download-button',
            },
            'Download PDF'
        );
    }
});
